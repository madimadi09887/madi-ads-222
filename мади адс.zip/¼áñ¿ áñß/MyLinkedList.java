public class MyLinkedList<T> implements MyList<T> {
    private class Node {
        T element;
        Node prev;
        Node next;

        Node(T element, Node prev, Node next) {
            this.element = element;
            this.prev = prev;
            this.next = next;
        }
    }

    private Node head;
    private Node tail;
    private int size;

    public MyLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean contains(Object o) {
        return indexOf(o) != -1;
    }

    @Override
    public void add(T item) {
        add(item, size);
    }

    @Override
    public void add(T item, int index) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Invalid index");
        }

        if (index == size) {
            Node newNode = new Node(item, tail, null);
            if (tail != null) {
                tail.next = newNode;
            } else {
                head = newNode;
            }
            tail = newNode;
        } else {
            Node nodeAtIndex = getNode(index);
            Node newNode = new Node(item, nodeAtIndex.prev, nodeAtIndex);
            if (nodeAtIndex.prev != null) {
                nodeAtIndex.prev.next = newNode;
            } else {
                head = newNode;
            }
            nodeAtIndex.prev = newNode;
        }

        size++;
    }

    @Override
    public boolean remove(T item) {
        int index = indexOf(item);
        if (index != -1) {
            remove(index);
            return true;
        }
        return false;
    }

    @Override
    public T remove(int index) {
        Node nodeToRemove = getNode(index);
        T removedElement = nodeToRemove.element;

        if (nodeToRemove.prev != null) {
            nodeToRemove.prev.next = nodeToRemove.next;
        } else {
            head = nodeToRemove.next;
        }

        if (nodeToRemove.next != null) {
            nodeToRemove.next.prev = nodeToRemove.prev;
        } else {
            tail = nodeToRemove.prev;
        }

        nodeToRemove.prev = null;
        nodeToRemove.next = null;
        nodeToRemove.element = null;
        size--;

        return removedElement;
    }

    @Override
    public void clear() {
        Node currentNode = head;
        while (currentNode != null) {
            Node nextNode = currentNode.next;
            currentNode.prev = null;
            currentNode.next = null;
            currentNode.element = null;
            currentNode = nextNode;
        }
        head = null;
        tail = null;
        size = 0;
    }

    @Override
    public T get(int index) {
        return getNode(index).element;
    }

    @Override
    public int indexOf(Object o) {
        int index = 0;
        Node currentNode = head;
        while (currentNode != null) {
            if (currentNode.element.equals(o)) {
                return index;
            }
            currentNode = currentNode.next;
            index++;
        }
        return -1;
    }

    @Override
    public int lastIndexOf(Object o) {
        int index = size - 1;
        Node currentNode = tail;
        while (currentNode != null) {
            if (currentNode.element.equals(o)) {
                return index;
            }
            currentNode = currentNode.prev;
            index--;
        }
        return -1;
    }

    @Override
    public void sort() {
        // Not implemented for LinkedList
        // Sorting a linked list is a complex task beyond the scope of this exercise
        throw new UnsupportedOperationException("Sort operation is not supported for LinkedList");
    }

    private Node getNode(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Invalid index");
        }

        if (index <= size / 2) {
            Node currentNode = head;
            for (int i = 0; i < index; i++) {
                currentNode = currentNode.next;
            }
            return currentNode;
        } else {
            Node currentNode = tail;
            for (int i = size - 1; i > index; i--) {
                currentNode = currentNode.prev;
            }
            return currentNode;
        }
    }
}
